const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());

app.use(express.static(path.join(__dirname, 'public')));

const SECRET_KEY = 'your-secret-key';

// Директория данных
const dataDirectory = path.join(__dirname, 'data');

// Функция для обеспечения существования файла
const ensureFileExists = (filePath, defaultContent) => {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultContent, null, 2));
    }
};

// Обеспечиваем существование необходимых файлов
ensureFileExists(path.join(dataDirectory, 'projects.json'), []);
ensureFileExists(path.join(dataDirectory, 'generationProjects.json'), []);
ensureFileExists(path.join(dataDirectory, 'realizationProjects.json'), []);
ensureFileExists('./users.json', []);
ensureFileExists('./statuses.json', [
    { "name": "Запрос", "color": "#007bff" },
    { "name": "Ожидание согласования договора", "color": "#ffc107" },
    { "name": "Ожидание Оплаты", "color": "#17a2b8" },
    { "name": "В пути", "color": "#28a745" },
    { "name": "Выполнено", "color": "#6c757d" },
    { "name": "Отклонено", "color": "#dc3545" }
]);

let users = require('./users.json');
let statuses = require('./statuses.json');

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

const authorizeRole = (role) => {
    return (req, res, next) => {
        if (req.user.role !== role) {
            return res.sendStatus(403);
        }
        next();
    };
};

app.post('/auth/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);
    if (user == null) {
        return res.status(400).send('Cannot find user');
    }
    if (!bcrypt.compareSync(password, user.password)) {
        return res.status(403).send('Invalid credentials');
    }
    const accessToken = jwt.sign({ username: user.username, role: user.role, firstName: user.firstName, lastName: user.lastName }, SECRET_KEY);
    res.json({ accessToken, role: user.role, firstName: user.firstName, lastName: user.lastName });
});

app.post('/auth/register', (req, res) => {
    const { firstName, lastName, username, password, role } = req.body;
    const user = {
        id: users.length + 1,
        firstName,
        lastName,
        username,
        password: bcrypt.hashSync(password, 10),
        role: role || 'user'
    };
    users.push(user);
    fs.writeFileSync('./users.json', JSON.stringify(users, null, 2));
    const accessToken = jwt.sign({ username: user.username, role: user.role, firstName: user.firstName, lastName: user.lastName }, SECRET_KEY);
    res.json({ accessToken, role: user.role, firstName: user.firstName, lastName: user.lastName });
});

app.delete('/auth/delete', authenticateToken, authorizeRole('admin'), (req, res) => {
    const { username } = req.body;
    const userIndex = users.findIndex(user => user.username === username);
    if (userIndex === -1) {
        return res.status(404).send('User not found');
    }
    users.splice(userIndex, 1);
    fs.writeFileSync('./users.json', JSON.stringify(users, null, 2));
    res.status(200).send('User deleted successfully');
});

app.delete('/projects/:projectId', authenticateToken, async (req, res) => {
    const { projectId } = req.params;
    const type = req.query.type;

    try {
        const filePaths = {
            projects: './data/projects.json',
            generation: './data/generationProjects.json',
            realization: './data/realizationProjects.json'
        };

        const filePath = filePaths[type];
        if (!filePath) {
            return res.status(400).json({ message: 'Invalid project type' });
        }

        const projects = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        const projectIndex = projects.findIndex(project => project.id === projectId);

        if (projectIndex === -1) {
            return res.status(404).json({ message: 'Project not found' });
        }

        // Удаляем проект
        projects.splice(projectIndex, 1);

        // Обновляем зависимости
        const allProjects = [...projects];
        const otherFiles = Object.keys(filePaths).filter(key => key !== type);
        for (const otherFile of otherFiles) {
            const otherProjects = JSON.parse(fs.readFileSync(filePaths[otherFile], 'utf8'));
            allProjects.push(...otherProjects);
        }

        allProjects.forEach(project => {
            if (project.dependencies) {
                project.dependencies = project.dependencies.filter(dep => dep !== projectId);
            }
        });

        // Записываем обновленные данные обратно в файл
        fs.writeFileSync(filePath, JSON.stringify(projects, null, 2));

        res.status(200).json({ message: 'Project deleted and dependencies updated' });
    } catch (error) {
        console.error('Error deleting project:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.post('/projects', authenticateToken, async (req, res) => {
    const projectData = req.body;
    const projects = readProjects(projectData.type);

    projects.push(projectData);
    writeProjects(projectData.type, projects);

    if (projectData.dependencies && projectData.dependencies.length > 0) {
        await updateDependenciesForProject(projectData.id, projectData.dependencies);
    }

    res.json({ message: 'Project added successfully' });
});

const readProjects = (type) => {
    if (type === 'generation') {
        return JSON.parse(fs.readFileSync(path.join(dataDirectory, 'generationProjects.json')));
    } else if (type === 'realization') {
        return JSON.parse(fs.readFileSync(path.join(dataDirectory, 'realizationProjects.json')));
    } else {
        return JSON.parse(fs.readFileSync(path.join(dataDirectory, 'projects.json')));
    }
};

const writeProjects = (type, projects) => {
    if (type === 'generation') {
        fs.writeFileSync(path.join(dataDirectory, 'generationProjects.json'), JSON.stringify(projects, null, 2));
    } else if (type === 'realization') {
        fs.writeFileSync(path.join(dataDirectory, 'realizationProjects.json'), JSON.stringify(projects, null, 2));
    } else {
        fs.writeFileSync(path.join(dataDirectory, 'projects.json'), JSON.stringify(projects, null, 2));
    }
};

app.get('/data/projects', authenticateToken, (req, res) => {
    try {
        const projects = readProjects('projects');
        res.json(projects);
    } catch (err) {
        console.error('Error fetching projects:', err);
        res.status(500).json({ error: 'Failed to fetch projects' });
    }
});

app.get('/data/generationProjects', authenticateToken, (req, res) => {
    try {
        const projects = readProjects('generation');
        res.json(projects);
    } catch (err) {
        console.error('Error fetching generation projects:', err);
        res.status(500).json({ error: 'Failed to fetch generation projects' });
    }
});

app.get('/data/realizationProjects', authenticateToken, (req, res) => {
    try {
        const projects = readProjects('realization');
        res.json(projects);
    } catch (err) {
        console.error('Error fetching realization projects:', err);
        res.status(500).json({ error: 'Failed to fetch realization projects' });
    }
});

app.patch('/projects/:id', authenticateToken, (req, res) => {
    const { id } = req.params;
    const { name, startDate, endDate, status, employees, comments, type, phase, weight, budget, goals, dependencies } = req.body;

    if (!type) {
        return res.status(400).send('Type is required');
    }

    let projects = readProjects(type);
    let project = projects.find(p => p.id === id);

    if (!project) {
        return res.status(404).send('Project not found');
    }

    project.name = name;
    project.startDate = startDate;
    project.endDate = endDate;
    project.status = status;
    project.employees = employees;
    project.comments = comments;
    project.phase = phase;
    project.weight = weight;
    project.budget = budget;
    project.goals = goals;
    project.dependencies = dependencies;

    writeProjects(type, projects);
    res.status(200).send('Project updated successfully');
});

app.patch('/projects/:id/rating', authenticateToken, (req, res) => {
    const { id } = req.params;
    const { ratingType, rating, type, goalName } = req.body;

    if (!type) {
        console.error('Type is required');
        return res.status(400).send('Type is required');
    }

    let projects = readProjects(type);
    let project = projects.find(p => p.id === id);

    if (!project) {
        console.error('Project not found');
        return res.status(404).send('Project not found');
    }

    if (project.goals && project.goals.length > 0) {
        const goal = project.goals.find(g => g.name === goalName);
        if (goal) {
            if (ratingType === 'manager') {
                goal.rating = rating;
            } else if (ratingType === 'customer') {
                goal.customerRating = rating;
            }
        }
    }

    writeProjects(type, projects);
    console.log(`Updated ${ratingType} rating for goal in project ${id} to ${rating}`);
    console.log(`Updated project data:`, project);
    res.status(200).send('Goal rating updated successfully');
});

app.patch('/projects/:projectId/status', authenticateToken, async (req, res) => {
    const { projectId } = req.params;
    const { goalName, status, type } = req.body;
    const projectsPath = getProjectsPath(type);

    try {
        await updateProject(projectsPath, projectId, project => {
            const goal = project.goals.find(g => g.name === goalName);
            if (goal) {
                goal.status = status;
            }
        });
        res.sendStatus(200);
    } catch (err) {
        res.status(500).json({ error: 'Failed to update goal status' });
    }
});

app.get('/statuses', authenticateToken, (req, res) => {
    res.json(statuses);
});

app.patch('/statuses', authenticateToken, (req, res) => {
    statuses = req.body;
    fs.writeFileSync('./statuses.json', JSON.stringify(statuses, null, 2));
    console.log('Statuses updated');
    res.status(200).send('Statuses updated successfully');
});

app.patch('/projects/:id/completion-date', authenticateToken, (req, res) => {
    const projectId = req.params.id;
    const { date, type } = req.body;

    console.log(`Updating completion date for project ${projectId} of type ${type} to ${date}`);

    let projects = readProjects(type);

    const project = projects.find(p => p.id === projectId);
    if (!project) {
        console.error('Project not found:', projectId);
        return res.status(404).json({ error: 'Project not found' });
    }

    project.finalCompletionDate = date;

    try {
        writeProjects(type, projects);
        console.log(`Completion date updated successfully for project ${projectId}`);
        res.json({ message: 'Completion date updated successfully' });
    } catch (err) {
        console.error('Error writing to file:', err);
        res.status(500).json({ error: 'Failed to update completion date' });
    }
});

app.patch('/projects/:id/goal', authenticateToken, (req, res) => {
    const { id } = req.params;
    const { goalName, type } = req.body;

    if (!type) {
        return res.status(400).send('Type is required');
    }

    let projects = readProjects(type);
    let project = projects.find(p => p.id === id);

    if (!project) {
        return res.status(404).send('Project not found');
    }

    project.goals.forEach(goal => goal.selected = goal.name === goalName);

    writeProjects(type, projects);
    res.status(200).send('Goal updated successfully');
});

app.patch('/projects/:id/transfer', authenticateToken, (req, res) => {
    const { id } = req.params;
    const { newEmployee } = req.body;

    let projects = readProjects('projects');
    let project = projects.find(p => p.id === id);

    if (!project) {
        return res.status(404).send('Project not found');
    }

    project.employees = [newEmployee];
    writeProjects('projects', projects);

    res.status(200).send('Project transferred successfully');
});

app.patch('/projects/:id/add-employee', authenticateToken, (req, res) => {
    const { id } = req.params;
    const { newEmployee } = req.body;

    let projects = readProjects('projects');
    let project = projects.find(p => p.id === id);

    if (!project) {
        return res.status(404).send('Project not found');
    }

    if (!project.employees.includes(newEmployee)) {
        project.employees.push(newEmployee);
        writeProjects('projects', projects);
        res.status(200).send('Employee added successfully');
    } else {
        res.status(400).send('Employee already assigned to the project');
    }
});

app.patch('/projects/:id/remove-employee', authenticateToken, (req, res) => {
    const { id } = req.params;
    const { employeeToRemove } = req.body;

    let projects = readProjects('projects');
    let project = projects.find(p => p.id === id);

    if (!project) {
        return res.status(404).send('Project not found');
    }

    project.employees = project.employees.filter(employee => employee !== employeeToRemove);
    writeProjects('projects', projects);

    res.status(200).send('Employee removed successfully');
});

const updateDependenciesForProject = async (projectId, dependencies) => {
    try {
        const updateDependencyInFile = async (filePath, projectId, dependencyId) => {
            let projects = JSON.parse(await fs.promises.readFile(filePath, 'utf8'));
            let project = projects.find(p => p.id === dependencyId);
            if (!project) return false;

            if (!project.dependencies) project.dependencies = [];
            if (!project.dependencies.includes(projectId)) {
                project.dependencies.push(projectId);
            }

            await fs.promises.writeFile(filePath, JSON.stringify(projects, null, 2));
            return true;
        };

        for (const dependencyId of dependencies) {
            await updateDependencyInFile(path.join(dataDirectory, 'projects.json'), projectId, dependencyId);
            await updateDependencyInFile(path.join(dataDirectory, 'generationProjects.json'), projectId, dependencyId);
            await updateDependencyInFile(path.join(dataDirectory, 'realizationProjects.json'), projectId, dependencyId);
        }
    } catch (err) {
        console.error('Error updating dependencies:', err);
        throw err;
    }
};

app.patch('/projects/update-dependency', authenticateToken, async (req, res) => {
    const { projectId, dependencyId } = req.body;

    try {
        const projectFiles = ['projects.json', 'generationProjects.json', 'realizationProjects.json'];
        for (const file of projectFiles) {
            const filePath = path.join(dataDirectory, file);
            const data = JSON.parse(fs.readFileSync(filePath));

            const project = data.find(p => p.id === dependencyId);
            if (project) {
                if (!Array.isArray(project.dependencies)) {
                    project.dependencies = [];
                }
                if (!project.dependencies.includes(projectId)) {
                    project.dependencies.push(projectId);
                }
                fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
            }
        }

        res.status(200).json({ message: 'Dependency updated successfully' });
    } catch (error) {
        console.error('Error updating dependency:', error);
        res.status(500).json({ message: 'Error updating dependency' });
    }
});

const getProjectsPath = (type) => {
    switch (type) {
        case 'generation':
            return path.join(dataDirectory, 'generationProjects.json');
        case 'realization':
            return path.join(dataDirectory, 'realizationProjects.json');
        default:
            return path.join(dataDirectory, 'projects.json');
    }
};

const updateProject = async (projectsPath, projectId, updateFn) => {
    const projects = await readData(projectsPath);
    const projectIndex = projects.findIndex(p => p.id === projectId);
    if (projectIndex === -1) {
        throw new Error('Project not found');
    }
    updateFn(projects[projectIndex]);
    await writeData(projectsPath, projects);
};

const readData = (path) => {
    return new Promise((resolve, reject) => {
        fs.readFile(path, 'utf8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(JSON.parse(data));
            }
        });
    });
};

const writeData = (path, data) => {
    return new Promise((resolve, reject) => {
        fs.writeFile(path, JSON.stringify(data, null, 2), 'utf8', (err) => {
            if (err) {
                reject(err);
            } else {
                resolve();
            }
        });
    });
};

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
